$('h1')
m.fn.init [h1, prevObject: m.fn.init(1), context: document, selector: "h1"]
$('h1')[0]
<h1>​I'm AAKASH HANDA​</h1>​
$('.scroll')[0]
<a href=​"#skills" class=​"scroll">​Skills​</a>​
$('#abc')[0]
undefined
$('#abc')
m.fn.init {context: document, selector: "#abc"}

$('h1')[0].innerText
"I'm AAKASH HANDA"
$('h1')[0].innerText="I m from developer funnel"
"I m from developer funnel"